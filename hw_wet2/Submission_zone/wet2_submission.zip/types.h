#include <memory>

// type definitions which are used all over the program

class Lecture;
class Course;
typedef struct std::shared_ptr<Lecture> Lecture_ptr;
typedef struct std::shared_ptr<Course> Course_ptr;